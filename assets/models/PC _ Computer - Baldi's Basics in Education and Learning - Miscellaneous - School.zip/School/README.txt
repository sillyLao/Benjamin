School from Baldi's Basics in Education and Learning ripped by DogToon64.

If used, give credit to Mystman12.

Credit to DogToon64 is optional, but would be nice.